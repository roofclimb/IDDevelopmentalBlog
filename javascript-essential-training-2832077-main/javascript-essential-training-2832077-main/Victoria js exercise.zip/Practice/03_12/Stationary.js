class Stationary{
    constructor(
        name,
        color,
        length,
        ink
    )
    {
        this.name=name;
        this.color=color;
        this.length=length;
        this.ink=ink;

    }

}

export default Stationary;