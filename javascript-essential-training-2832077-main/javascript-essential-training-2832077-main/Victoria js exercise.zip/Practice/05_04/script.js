/**
 * Note: This file is intentionally empty.
 * You can use it to test your skills at traversing the DOM using JavaScript.
 */
console.log(document.querySelector("main"));
console.log(document.querySelector("main li:last-child"));
console.log(document.querySelectorAll("main li").forEach(item => item.style.backgroundColor="red"));
